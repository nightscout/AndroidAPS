package app.aaps.plugins.eversense.packets.e3

class EversenseE3Packets {
    companion object {
        const val AssertSnoozeAgainsAlarmCommandId = 20.toByte()
        const val AssertSnoozeAgainsAlarmResponseId = 148.toByte()
        const val CalibrationAlertPush = 77.toByte()
        const val CalibrationPush = 67.toByte()
        const val CalibrationSwitchPush = 76.toByte()
        const val ChangeTimingParametersCommandId = 117.toByte()
        const val ChangeTimingParametersResponseId = 245.toByte()
        const val ClearErrorFlagsCommandId = 4.toByte()
        const val ClearErrorFlagsResponseId = 132.toByte()
        const val DisconnectBLESavingBondingInformationCommandId = 116.toByte()
        const val DisconnectBLESavingBondingInformationResponseId = 244.toByte()
        const val EnterDiagnosticModeCommandId = 118.toByte()
        const val EnterDiagnosticModeResponseId = 246.toByte()
        const val ErrorResponseId = 128.toByte()
        const val ExerciseVibrationCommandId = 106.toByte()
        const val ExerciseVibrationResponseId = 234.toByte()
        const val ExitDiagnosticModeCommandId = 119.toByte()
        const val ExitDiagnosticModeResponseId = 247.toByte()
        const val GlucoseLevelAlarmPush = 64.toByte()
        const val GlucoseLevelAlertPush = 65.toByte()
        const val HardwareStatusPush = 69.toByte()
        const val KeepAlivePush = 80.toByte()
        const val LinkTransmitterWithSensorCommandId = 2.toByte()
        const val LinkTransmitterWithSensorResponseId = 130.toByte()
        const val MarkPatientEventRecordAsDeletedCommandId = 29.toByte()
        const val MarkPatientEventRecordAsDeletedResponseId = 157.toByte()
        const val PingCommandId = 1.toByte()
        const val PingResponseId = 129.toByte()
        const val RateAndPredictiveAlertPush = 66.toByte()
        const val ReadAllAvailableSensorsResponseId = 134.toByte()
        const val ReadAllSensorGlucoseAlertsInSpecifiedRangeCommandId = 113.toByte()
        const val ReadAllSensorGlucoseAlertsInSpecifiedRangeResponseId = 241.toByte()
        const val ReadAllSensorGlucoseDataInSpecifiedRangeCommandId = 112.toByte()
        const val ReadAllSensorGlucoseDataInSpecifiedRangeResponseId = 240.toByte()
        const val ReadCurrentTransmitterDateAndTimeCommandId = 25.toByte()
        const val ReadCurrentTransmitterDateAndTimeResponseId = 153.toByte()
        const val ReadFirstAndLastBloodGlucoseDataRecordNumbersCommandId = 23.toByte()
        const val ReadFirstAndLastBloodGlucoseDataRecordNumbersResponseId = 151.toByte()
        const val ReadFirstAndLastErrorLogRecordNumbersCommandId = 39.toByte()
        const val ReadFirstAndLastErrorLogRecordNumbersResponseId = 167.toByte()
        const val ReadFirstAndLastMiscEventLogRecordNumbersCommandId = 35.toByte()
        const val ReadFirstAndLastMiscEventLogRecordNumbersResponseId = 163.toByte()
        const val ReadFirstAndLastPatientEventRecordNumbersCommandId = 28.toByte()
        const val ReadFirstAndLastPatientEventRecordNumbersResponseId = 156.toByte()
        const val ReadFirstAndLastSensorGlucoseAlertRecordNumbersCommandId = 18.toByte()
        const val ReadFirstAndLastSensorGlucoseAlertRecordNumbersResponseId = 146.toByte()
        const val ReadFirstAndLastSensorGlucoseRecordNumbersCommandId = 14.toByte()
        const val ReadFirstAndLastSensorGlucoseRecordNumbersResponseId = 142.toByte()
        const val ReadFourByteSerialFlashRegisterCommandId = 46.toByte()
        const val ReadFourByteSerialFlashRegisterResponseId = 174.toByte()
        const val ReadLogOfBloodGlucoseDataInSpecifiedRangeCommandId = 114.toByte()
        const val ReadLogOfBloodGlucoseDataInSpecifiedRangeResponseId = 242.toByte()
        const val ReadLogOfPatientEventsInSpecifiedRangeCommandId = 115.toByte()
        const val ReadLogOfPatientEventsInSpecifiedRangeResponseId = 243.toByte()
        const val ReadNByteSerialFlashRegisterCommandId = 48.toByte()
        const val ReadNByteSerialFlashRegisterResponseId = 176.toByte()
        const val ReadSensorGlucoseAlertsAndStatusCommandId = 16.toByte()
        const val ReadSensorGlucoseAlertsAndStatusResponseId = 144.toByte()
        const val ReadSensorGlucoseCommandId = 8.toByte()
        const val ReadSensorGlucoseResponseId = 136.toByte()
        const val ReadSingleBloodGlucoseDataRecordCommandId = 22.toByte()
        const val ReadSingleBloodGlucoseDataRecordResponseId = 150.toByte()
        const val ReadSingleByteSerialFlashRegisterCommandId = 42.toByte()
        const val ReadSingleByteSerialFlashRegisterResponseId = 170.toByte()
        const val ReadSingleMiscEventLogCommandId = 34.toByte()
        const val ReadSingleMiscEventLogResponseId = 162.toByte()
        const val ReadSinglePatientEventCommandId = 27.toByte()
        const val ReadSinglePatientEventResponseId = 155.toByte()
        const val ReadSingleSensorGlucoseAlertRecordCommandId = 17.toByte()
        const val ReadSingleSensorGlucoseAlertRecordResponseId = 145.toByte()
        const val ReadSingleSensorGlucoseDataRecordResponseId = 137.toByte()
        const val ReadTwoByteSerialFlashRegisterCommandId = 44.toByte()
        const val ReadTwoByteSerialFlashRegisterResponseId = 172.toByte()
        const val ResetTransmitterCommandId = 3.toByte()
        const val ResetTransmitterResponseId = 131.toByte()
        const val SaveBLEBondingInformationCommandId = 105.toByte()
        const val SaveBLEBondingInformationResponseId = 233.toByte()
        const val SendBloodGlucoseDataCommandId = 21.toByte()
        const val SendBloodGlucoseDataResponseId = 149.toByte()
        // E3 uses a different calibration command with two timestamps (sample + current)
        const val SendBloodGlucoseDataWithTwoTimestampsCommandId = 60.toByte()   // 0x3C
        const val SendBloodGlucoseDataWithTwoTimestampsResponseId = 188.toByte() // 0xBC

        const val SensorReadAlertPush = 73.toByte()
        const val SensorReplacement2Push = 75.toByte()
        const val SensorReplacementPush = 68.toByte()
        const val SetCurrentTransmitterDateAndTimeCommandId = 7.toByte()
        const val SetCurrentTransmitterDateAndTimeResponseId = 135.toByte()
        const val StartSelfTestSequenceCommandId = 5.toByte()
        const val StartSelfTestSequenceResponseId = 133.toByte()
        const val TestResponseId = 224.toByte()
        const val TransmitterBatteryPush = 71.toByte()
        const val TransmitterEOLPush = 74.toByte()
        const val WriteFourByteSerialFlashRegisterCommandId = 47.toByte()
        const val WriteFourByteSerialFlashRegisterResponseId = 175.toByte()
        const val WriteNByteSerialFlashRegisterCommandId = 49.toByte()
        const val WriteNByteSerialFlashRegisterResponseId = 177.toByte()
        const val WritePatientEventCommandId = 26.toByte()
        const val WritePatientEventResponseId = 154.toByte()
        const val WriteSingleByteSerialFlashRegisterCommandId = 43.toByte()
        const val WriteSingleByteSerialFlashRegisterResponseId = 171.toByte()
        const val WriteSingleMiscEventLogRecordCommandId = 36.toByte()
        const val WriteSingleMiscEventLogRecordResponseId = 164.toByte()
        const val WriteTwoByteSerialFlashRegisterCommandId = 45.toByte()
        const val WriteTwoByteSerialFlashRegisterResponseId = 173.toByte()

        fun isPushPacket(data: Byte): Boolean {
            // KeepAlivePush (0x50) triggers normal glucose + sync cycle.
            // GlucoseLevelAlarmPush (0x40), GlucoseLevelAlertPush (0x41),
            // RateAndPredictiveAlertPush (0x42) are glucose push notifications
            // that the transmitter sends unsolicited after calibration or alarm events.
            // TransmitterBatteryPush (0x47) and SensorReadAlertPush (0x49) are also
            // push packets — without them AAPS would wait up to 100s for KeepAlive
            // instead of reacting immediately to the real-time glucose push.
            return data == KeepAlivePush ||
                   data == GlucoseLevelAlarmPush ||
                   data == GlucoseLevelAlertPush ||
                   data == RateAndPredictiveAlertPush ||
                   data == TransmitterBatteryPush ||
                   data == SensorReadAlertPush
        }

        fun isErrorPacket(data: Byte): Boolean {
            return data == ErrorResponseId
        }
    }
}