package app.aaps.plugins.eversense.models

import app.aaps.plugins.eversense.enums.CalibrationMode
import app.aaps.plugins.eversense.packets.e365.CalibrationHistoryItem
import app.aaps.plugins.eversense.enums.CalibrationPhase
import app.aaps.plugins.eversense.enums.CalibrationReadiness
import kotlinx.serialization.Serializable

@Serializable
class EversenseState {
    var lastSync: Long = 0
    var insertionDate: Long = 0
    var calibrationPhase: CalibrationPhase = CalibrationPhase.UNKNOWN
    var calibrationReadiness: CalibrationReadiness = CalibrationReadiness.REASON_UNKNOWN
    var calibrationMode: CalibrationMode = CalibrationMode.DEFAULT
    var nextCalibrationDate: Long = 0
    var lastCalibrationDate: Long = 0
    var batteryPercentage: Int = 0
    var recentGlucoseDatetime: Long = 0
    var recentGlucoseValue: Int = 0
    var lastGlucoseRaw: Int = 0
    var placementSignalRssi: Int = 0
    var sensorSignalStrength: Int = 0
    var activeAlarms: List<ActiveAlarm> = emptyList()
    var firmwareVersion: String = ""
    var mmaFeatures: Int = 0
    var extFirmwareVersion: String = ""
    var transmitterSerialNumber: String = ""
    var transmitterName: String = ""
    var sensorId: String = ""
    var settings = EversenseTransmitterSettings()
    var calibrationHistory: List<CalibrationHistoryItem> = emptyList()
}

@Serializable
class EversenseTransmitterSettings {
    var vibrateEnabled: Boolean = true
    var glucoseHighAlarmEnabled: Boolean = true
    var glucoseHighAlarmThreshold: Int = 250
    var glucoseLowAlarmThreshold: Int = 60
    var rateFallingAlarmEnabled: Boolean = true
    var rateFallingAlarmThreshold: Double = 1.5
    var rateRisingAlarmEnabled: Boolean = true
    var rateRisingAlarmThreshold: Double = 1.5
    var predictiveHighAlarmEnabled: Boolean = true
    var predictiveHighAlarmThreshold: Int = 180
    var predictiveHighAlarmMinutes: Int = 5
    var predictiveLowAlarmEnabled: Boolean = true
    var predictiveLowAlarmThreshold: Int = 70
    var predictiveLowAlarmMinutes: Int = 5
}

